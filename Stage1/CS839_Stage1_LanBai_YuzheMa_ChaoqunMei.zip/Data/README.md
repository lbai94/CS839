# Markups
All Human names are marked with ^NAME^. Example: ^Tony Blair^ says he will be facing the issue of trust and his own integrity head on during the election campaign.